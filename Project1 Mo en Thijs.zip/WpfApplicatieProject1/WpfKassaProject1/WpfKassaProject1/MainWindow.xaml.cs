﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfKassaProject1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double Fietsen = 0.00;
        double Verzekeringen = 0.00;
        double Services = 0.00;
        double Totaal = 0.00;
        double Eindprijs = 0.00;
        double PrijsBestel = 0.00;
        DispatcherTimer pbarTimer = new DispatcherTimer();
        int dagenKeer = 0;
        List<double> prijsArray = new List<double>();


        public MainWindow()
        {
            InitializeComponent();
            InitializeProgressbar();
            ComboFietsen.SelectedIndex = 0;
            ComboVerzekering.SelectedIndex = 0;
            ComboService.SelectedIndex = 0;
        }

        private void InitializeProgressbar()
        {
            pBar.Maximum = 60;
            pBar.Minimum = 0;
            pBar.Value = 60; 
            pbarTimer.Interval = TimeSpan.FromMilliseconds(1000);
            pbarTimer.Tick += PbarTimer_Tick;
            pbarTimer.Start();
        }

        private void PbarTimer_Tick(object sender, EventArgs e)
        {
            pBar.Value -= 1;
            if (pBar.Value <= pBar.Minimum)
            {
                this.Close();
                pbarTimer.Stop();
            }
        }

        private void FietsBedrag(object sender, SelectionChangedEventArgs e)
        {
            int FietsPrijs = ComboFietsen.SelectedIndex;
            switch (FietsPrijs)
            {
                case 0:
                    PrijsFietsen.Text = "0.00";
                    pBar.Value = 60;
                    break;
                case 1:
                    PrijsFietsen.Text = "20.00";
                    Fietsen = 20.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 2:
                    PrijsFietsen.Text = "35.00";
                    Fietsen = 35.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 3:
                case 4:
                    PrijsFietsen.Text = "30.00";
                    Fietsen = 30.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 5:
                case 8:
                case 9:
                case 12:
                    PrijsFietsen.Text = "15.00";
                    Fietsen = 15.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 6:
                    PrijsFietsen.Text = "45.00";
                    Fietsen = 45.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 7:
                case 10:
                    PrijsFietsen.Text = "12.50";
                    Fietsen = 12.50;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;   
                case 11:
                    PrijsFietsen.Text = "10.00";
                    Fietsen = 10.00;
                    pBar.Value = 60;
                    ComboVerzekering.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
            }
        }

        private void VerzekeringBedrag(object sender, SelectionChangedEventArgs e)
        {
            int VerzekeringPrijs = ComboVerzekering.SelectedIndex;
            switch (VerzekeringPrijs)
            {
                case 0:
                    PrijsVerzekeringen.Text = "0.00";
                    Verzekeringen = 0.00;
                    pBar.Value = 60;                   
                    break;
                case 1:
                case 3:
                    PrijsVerzekeringen.Text = "5.00";
                    Verzekeringen = 5.00;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 2:
                    PrijsVerzekeringen.Text = "10.00";
                    Verzekeringen = 10.00;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
                case 4:
                    PrijsVerzekeringen.Text = "2.50";
                    Verzekeringen = 2.50;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    break;
            }
        }

        private void ServiceBedrag(object sender, SelectionChangedEventArgs e)
        {
            int ServicePrijs = ComboService.SelectedIndex;
            switch (ServicePrijs)
            {
                case 0:
                    PrijsServices.Text = "0.00";
                    Services = 0.00;
                    pBar.Value = 60;
                    break;
                case 1:
                    PrijsServices.Text = "15.00";
                    Services = 15.00;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;
                    break;
                case 2:
                    PrijsServices.Text = "10.00";
                    Services = 10.00;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;
                    break;
                case 3:
                    PrijsServices.Text = "12.50";
                    Services = 12.50;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;
                    break;
                case 4:
                    PrijsServices.Text = "20.00";
                    Services = 20.00;
                    pBar.Value = 60;
                    ComboFietsen.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;
                    break;
            }
        }

        private void updateTotal()
        {
            double subTotaal = 0;
            foreach (var item in prijsArray)
            {
                subTotaal += item;               
                
            }
            PrijsBestelling.Text = subTotaal.ToString();
        }

        private void Bestellen_Click(object sender, RoutedEventArgs e)
        {
            int Dagen = Convert.ToInt32(tbDagen.Text);
            double result = 0.00;
            pBar.Value = 60;
            try
            {
                if (ComboFietsen.SelectedIndex == 0 && ComboVerzekering.SelectedIndex == 0 && ComboService.SelectedIndex == 0)
                {

                }
                else
                {
                    if (Dagen > 0 && Dagen < 8)
                    {
                        dagenKeer = dagenKeer + Dagen;
                    }
                    else
                    {
                        MessageBox.Show("Je moet minimaal 1 dag huren en maximaal 7 dagen!!!");
                    }
                    result = (result + Fietsen + Verzekeringen + Services) * dagenKeer;
                    Totaal = Totaal + result;
                    Eindprijs = Eindprijs + result;
                    PrijsTotaal.Text = Totaal.ToString();

                    addValuesToList();
                    StackPanel myStackpanel = new StackPanel();
                    TextBlock tbArtikel1 = new TextBlock();
                    TextBlock tbArtikel2 = new TextBlock();
                    TextBlock tbArtikel3 = new TextBlock();
                    TextBlock tbDag = new TextBlock();
                    TextBlock tbPrijs = new TextBlock();
                    Button myButton = new Button();
                    myStackpanel.Orientation = Orientation.Horizontal;
                    tbArtikel1.Margin = new Thickness(25, 0, 0, 0);
                    tbArtikel1.Text = ComboFietsen.Text.ToString();
                    tbArtikel2.Margin = new Thickness(25, 0, 0, 0);
                    tbArtikel2.Text = ComboVerzekering.Text.ToString();
                    tbArtikel3.Margin = new Thickness(25, 0, 0, 0);
                    tbArtikel3.Text = ComboService.Text.ToString();
                    tbArtikel3.Margin = new Thickness(25, 0, 0, 0);
                    tbDag.Margin = new Thickness(25, 0, 0, 0);
                    tbDag.Text = tbDagen.Text.ToString();
                    tbPrijs.Margin = new Thickness(25, 0, 0, 0);
                    tbPrijs.Text = Totaal.ToString();
                    tbPrijs.Name = "tbPrijs";

                    if (ComboFietsen.SelectedIndex > 0)
                    {
                        myStackpanel.Children.Insert(0, tbArtikel1);
                    }
                    else if (ComboVerzekering.SelectedIndex > 0)
                    {
                        myStackpanel.Children.Insert(0, tbArtikel2);
                    }
                    else if (ComboService.SelectedIndex > 0)
                    {
                        myStackpanel.Children.Insert(0, tbArtikel3);
                    }

                    myButton.Background = Brushes.Red;
                    myButton.Margin = new Thickness(25, 0, 0, 0);
                    myButton.Content = "X";
                    myButton.Click += MyButton_ClickDeleteItem;
                    myStackpanel.Children.Insert(0, tbDag);
                    myStackpanel.Children.Insert(0, tbPrijs);
                    myStackpanel.Children.Insert(0, myButton);
                    lbBestelling.Items.Add(myStackpanel);

                    Fietsen = 0.00;
                    Verzekeringen = 0.00;
                    Services = 0.00;
                    Totaal = 0.00;
                    dagenKeer = 0;
                    tbDagen.Text = "1";
                    ComboFietsen.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " Je moet wel iets invullen!");
            }
        }
        private void Klant_Click(object sender, RoutedEventArgs e)
        {
            pBar.Value = 60;
            if (lbBestelling.Items.Count > 0)
            {
                MessageBoxResult result = MessageBox.Show("Heb je alles afgerekend?", "Afgerekend?", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Dankuwel voor het winkelen bij onze fietsen winkel.\nNog een Fijne dag verder!");
                    Fietsen = 0.00;
                    Verzekeringen = 0.00;
                    Services = 0.00;
                    Totaal = 0.00;
                    dagenKeer = 0;
                    PrijsTotaal.Text = "0.00";
                    PrijsBestelling.Text = "0.00";
                    tbDagen.Text = "1";
                    ComboFietsen.SelectedIndex = 0;
                    ComboService.SelectedIndex = 0;
                    ComboVerzekering.SelectedIndex = 0;
                }
                else if (result == MessageBoxResult.No)
                {
                    MessageBox.Show("U moet wel afrekenen!");
                }
            }
            else
            {
                MessageBox.Show("We vinden het jammer dat we u vandaag niet konden helpen,\nWe hopen erop dat we u de volgende keer wel kunnen helpen.");
            }
        }

        private void Reken_Click(object sender, RoutedEventArgs e)
        {
            pbarTimer.Stop();
            pBar.Value = 60;
            Rekenmachine rekenmachine = new Rekenmachine();
            rekenmachine.ShowDialog();
            pbarTimer.Start();
        }
        private void addValuesToList()
        {
            double valueBestelling = 0;
            try
            {
                valueBestelling = Convert.ToDouble(PrijsTotaal.Text);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hey insert valid double values!!!\n" + ex.Message);
            }
            prijsArray.Add(valueBestelling);
            calculateTotal();
        }

        private void MyButton_ClickDeleteItem(object sender, RoutedEventArgs e)
        {
            StackPanel myTempPanel = ((Button)sender).Parent as StackPanel;
            double total = 0;
            foreach (var child in myTempPanel.Children)
            { 
                if ((child is TextBlock && (child as TextBlock).Name == "tbPrijs"))
                {
                    double tempValue = Convert.ToDouble(((TextBlock)child).Text);
                    int index = prijsArray.IndexOf(tempValue);
                    prijsArray.RemoveAt(index);
                    total += tempValue;
                }
            }
            int myListboxIndex = lbBestelling.Items.IndexOf(myTempPanel);
            lbBestelling.Items.RemoveAt(myListboxIndex);
            calculateTotal();
        }

        private void calculateTotal()
        {
            double total = 0;
            foreach (var item in prijsArray)
            {
                total += item;
            }
            PrijsBestelling.Text = total.ToString();

        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!IsNumericOrComma(e.Text))
            {
                e.Handled = true;
            }
        }
        private bool IsNumericOrComma(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c) && c != ',')
                {
                    return false;
                }
            }
            return true;
        }
    }
}
